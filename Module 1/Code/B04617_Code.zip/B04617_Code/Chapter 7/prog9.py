import cv2
img = cv2.imread('lena_color_512.tif',1)
print img.shape
print img.size
print img.dtype