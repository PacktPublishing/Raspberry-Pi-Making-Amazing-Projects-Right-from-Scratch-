Chapter 12, 13, 15 does not contain cpdes.

Chapter 12 describes about the Domain Name System and how to set up DNS 

The sections in Chapter 13 describes the steps of installing PHP and MySQL, also WordPress

Chapter 15 is the Appendix section it doesnt have code.
